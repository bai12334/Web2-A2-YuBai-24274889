const express = require('express');  
const bodyParser = require('body-parser');  
const cors = require('cors');  
const app = express();  
  
// 设置静态文件目录  
app.use(cors());  
app.use(bodyParser.json()); // 支持JSON编码的请求体  
app.use(bodyParser.urlencoded({ extended: true })); // 支持URL编码的请求体  
  
// 设置端口  
const PORT = process.env.PORT || 3000;  
app.listen(PORT, () => {  
    console.log(`Server is running on port ${PORT}`);  
});  

const connection = require('./db');  
  
  //Retrieve fundraising activities for all events, including categories
app.get('/fundraisers', (req, res) => {  
        connection.query(  
            `SELECT f.*, t.NAME AS CATEGORY_NAME  
            FROM fund_raiser f  
            LEFT JOIN types t ON f.CATEGORY_ID = t.CATEGORY_ID;`  
        ,(err, results) => {
        	res.json(results);  
        });  
});

//Retrieve all categories
app.get('/categories',  (req, res) => {  
        connection.query(`SELECT * FROM types;`,(err, results) => {  
			res.json(results);  
		});  
});

//Retrieve fundraisers for all category based activities
app.get('/category/:categoryId', (req, res) => {  
    const { categoryId } = req.params;  
        connection.query(  
            `SELECT f.*, t.NAME AS CATEGORY_NAME  
            FROM fund_raiser f  
            LEFT JOIN types t ON f.CATEGORY_ID = t.CATEGORY_ID  
            WHERE f.FUNDRAISER_ID = ?;`,  
            [categoryId],(err,results) => {  
				res.json(results);  
    });
}); 

//Retrieve detailed information of fundraisers by ID
app.get('/fundraisers/:fundraiserId', (req, res) => {  
    const { fundraiserId } = req.params;  
        connection.query(  
            `SELECT f.*, t.NAME AS CATEGORY_NAME  
            FROM fund_raiser f  
            LEFT JOIN types t ON f.CATEGORY_ID = t.CATEGORY_ID  
            WHERE f.FUNDRAISER_ID = ?;`,  
            [fundraiserId],(err,results) => {  
				res.json(results);  
    });
});

//Multi criteria search function based on organizer, city, and category
app.get('/search', (req, res) => {  
    const { organizer, city, categoryId } = req.query;  
    let sql = `SELECT f.*, t.NAME AS CATEGORY_NAME  
               FROM fund_raiser f  
               LEFT JOIN types t ON f.CATEGORY_ID = t.CATEGORY_ID WHERE f.ACTIVITY='active'`;  
			   
    let params = [];  
    let conditions = [];  
  
    if (organizer) {  
        conditions.push(`f.ORGANIZER LIKE ?`);  
        params.push(`%${organizer}%`);  
    }  
  
    if (city) {  
        conditions.push(`f.CITY LIKE ?`);  
        params.push(`%${city}%`);  
    }  
  
    if (categoryId) {  
        conditions.push(`f.CATEGORY_ID = ?`);  
        params.push(categoryId);  
    }  
  
    sql += `AND ${conditions.join(' AND ')}`;  
	
    connection.query(sql, params, (err, results) => {  
        res.json(results);  
    });  
});